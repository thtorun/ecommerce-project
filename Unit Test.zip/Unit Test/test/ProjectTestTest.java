
package fashiopproject;

import org.junit.Test;
import static org.junit.Assert.*;

public class ProjectTestTest {
    
    public ProjectTestTest() {
        
    }

    /**
     * Test of getAccess method, of class ProjectTest.
     */
    //login part
    @Test
    public void testGetAccess() {
       ProjectTest obj1 = new ProjectTest ( );
       int actual;
       actual = obj1.getAccess("mahabur@","mrb12");
       assertEquals("Valid User",1, actual, 0.0001);
       assertNotEquals("Invalid User",2, actual, 0.0001);
       assertNotNull("Is null?", "Abideen@");
       assertNotSame("jht123", actual);
      
    }
    //add product part
    @Test
    public void addProduct(){
       ProjectTest obj1 = new ProjectTest ( );
       int actual;
       actual = obj1.addProduct("Car");
       assertEquals("Successful",1, actual, 0.0001);
       assertNotNull("Is null?", "Bus");
       
    }
}
