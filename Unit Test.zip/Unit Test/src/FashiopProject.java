package fashiopproject;

import java.util.Scanner;
import javafx.scene.layout.Region;

public class FashiopProject {

  
    public static void main(String[] args) {
        
       
        
        // login Section
       Scanner scan = new Scanner(System.in); 
       String ID, password;
       
        System.out.println("Enter your Mail and password: ");
        
        ID = scan.next();
        password = scan.next();
        ProjectTest obj_login = new ProjectTest();
        int result = obj_login.getAccess(ID, password);
        
        if(result == 0){
            System.out.println("You are not registard. Sign Up first");
        }
        else
            System.out.println("Successfuly Logged in");
        
        // add Product Section
        
         
       
        System.out.println("Enter your Prodeuct name: ");
        
        String P_name = scan.next();
        int P_result = obj_login.addProduct(P_name);
        if(P_result == 0){
            System.out.println("Something went wrong when add product!");
        }
        else
            System.out.println("Product successfuly added");
        
    }
    
}
