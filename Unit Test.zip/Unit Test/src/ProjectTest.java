package fashiopproject;

import java.util.ArrayList;
import java.util.List;

public class ProjectTest {
    
    String []ID =  {"mahabur@", "tarek@", "farhad@", "siam@"};
    String []password = {"mrb12", "th12", "fa12", "jht12"};
    //String[] P_names ;
    
    //login part
    public int getAccess(String id, String pass){
        for(int i = 0; i<ID.length; i++){
            if(id.equals(ID[i]) && pass.equals(password[i])){
                return 1;
            }
        }
        System.out.println("Invalid inputs");
        return 0;
    }
    //add product
    public int addProduct(String P_name){
        List<String> P_names =new ArrayList<String>(); 
        
        P_names.add(P_name);       
               
        if (P_names.contains(P_name) ){
             return 1;
        }else{
            
             return 0;
        }
    }
}
  
